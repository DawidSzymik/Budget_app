package com.example.pasir_szymik_dawid.model;

public enum TransactionType {
    INCOME,
    EXPENSE
}
