package lib.lab12.pasir_szymik_dawid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaSiRSzymikDawidApplicationTests {

    @Test
    void contextLoads() {
    }

}
