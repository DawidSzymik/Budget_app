package com.example.pasir_szymik_dawid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaSiRSzymikDawidApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaSiRSzymikDawidApplication.class, args);
    }

}
